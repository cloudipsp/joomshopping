INSERT INTO `#__jshopping_payment_method` (
	`payment_code`, 
	`payment_class`, 
	`payment_publish`, 
	`payment_ordering`, 
	`payment_type`, 
	`price`, 
	`price_type`, 
	`tax_id`, 
	`show_descr_in_email`, 
	`name_en-GB`,
	`name_de-DE`,
	`description_en-GB`	
	) VALUES (
	'Fondy bank links', 
	'pm_fondy_banks', 
	0, 
	0, 
	2, 
	0.00, 
	1, 
	-1, 
	0, 
	'Fondy bank links',
	'Fondy bank links',
	'<div style="max-width: 340px;display: flex;flex-flow: row wrap;justify-content: space-between;" class="flex-container">
        <div style="margin: auto;margin-left: 0;" class="flex-item">
            <img width="65" src="/components/com_jshopping/files/img_fondy/banks/csob.svg" alt="1" class="img-responsive"/>
        </div>
        <div style="margin: auto;margin-left: 0;" class="flex-item">
            <img width="65" src="/components/com_jshopping/files/img_fondy/banks/mbank.svg" alt="1" class="img-responsive"/>
        </div>
        <div style="margin: auto;margin-left: 0;" class="flex-item">
            <img width="65" src="/components/com_jshopping/files/img_fondy/banks/otp.svg" alt="1" class="img-responsive"/>
        </div>
        <div style="margin: auto;margin-left: 0;" class="flex-item">
            <img width="65" src="/components/com_jshopping/files/img_fondy/banks/pabk.svg" alt="1" class="img-responsive"/>
        </div>
    </div>
    <div style="margin-top: 10px; max-width: 340px;display: flex;flex-flow: row wrap;justify-content: space-between;"
         class="flex-container">
        <div style="margin: auto;margin-left: 0;" class="flex-item">
            <img width="65" src="/components/com_jshopping/files/img_fondy/banks/prima.svg" alt="1" class="img-responsive"/>
        </div>
        <div style="margin: auto;margin-left: 0;" class="flex-item">
            <img width="65" src="/components/com_jshopping/files/img_fondy/banks/sberbank.svg" alt="1" class="img-responsive"/>
        </div>
        <div style="margin: auto;margin-left: 0;" class="flex-item">
            <img width="65" src="/components/com_jshopping/files/img_fondy/banks/slsp.svg" alt="1" class="img-responsive"/>
        </div>
        <div style="margin: auto;margin-left: 0;" class="flex-item">
            <img width="65" src="/components/com_jshopping/files/img_fondy/banks/vub.svg" alt="1" class="img-responsive"/>
        </div>
    </div>'	
);