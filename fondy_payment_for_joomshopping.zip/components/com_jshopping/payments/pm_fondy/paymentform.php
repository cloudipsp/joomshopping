<?php 
/*
* @version      1.0.0
* @author       DM
* @package      Jshopping
* @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
*/
defined('_JEXEC') or die('Restricted access'); 
?>

<script type="text/javascript">
function check_pm_fondy(){
    jQuery('#payment_form').submit();
}
</script>